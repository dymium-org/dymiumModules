library(testthat)
test_check("demography")

# to test all the test cases run below
# test_dir("modules/demography/tests/testthat")

# or test a specific test file
# test_file("modules/demography/tests/testthat/test.R")